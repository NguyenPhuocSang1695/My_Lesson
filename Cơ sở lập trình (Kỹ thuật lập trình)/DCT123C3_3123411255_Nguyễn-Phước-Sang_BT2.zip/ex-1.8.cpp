//Bai 8
#include <iostream>
using namespace std;

//cau a
int tohop (int k, int n){
	if (k== 0|| k== n){
		return 1;
	}
	return tohop (k-1, n-1)+ tohop (k, n-1);
}

//cau b
//tinh cac gia tri trong tam giac
int pascal(int k, int n) {
    if (n == 0 || n == k)
        return 1;
    else
        return pascal(k - 1, n - 1) + pascal(k- 1, n);
}

//in cac khoang trang
void inspace(int m) {
    if (m == 0)
        return;
    
    cout << " ";
    inspace(m - 1);
}

//in cac so tren hang
void inso(int k, int n) {
    if (n > k)
        return;
    
    cout << pascal(k, n) << " ";
    inso(k, n + 1);
}


//in ra tam giac
void intg(int k, int h) {
    if (k == h)
        return;
	
	//in khoang trang
    inspace(h - k - 1);
    
    //in cac so tren hang
    inso(k, 0);
    cout << endl;
    
    // in hang tiep theo
    intg(k + 1, h);
}

int main() {
	//cau a
	int k, n;
	cin >> k >> n;
	if (k> n){
		cout << "Nhap lai!";
	}
	cout << tohop (k, n);
	cout << endl;
	//cau b
	//k hang, n cot, chieu cao h
    int h;
    cout << "Nhap chieu cao cua tam giac Pascal: ";
    cin >> h;
    intg(0, h);
    return 0;
}
