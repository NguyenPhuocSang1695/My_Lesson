//Bai 6
#include<iostream>
using namespace std;

int x(int n, int i= 0, int total= 0){
    if(n == 1 || n == 0) // dieu kien dung cua ham de quy
        return 1;
    else{
        if (i== n){ // dieu kien dung cua chuong trinh tinh tong
        	return total;
		}
        total += (n - i) * x(i); //tinh theo cong thuc de quy
        return x (n, i+1, total); //tang i tinh gia tri 
    }
    return 0; //khong thoa dieu kien
}

int main(){
    int n;
    cout << "x" << 7 << " = " << x(7) << endl;
    cout << "n= ";
    cin >> n;
    cout << "x" << n << " = " << x(n) << endl;
}