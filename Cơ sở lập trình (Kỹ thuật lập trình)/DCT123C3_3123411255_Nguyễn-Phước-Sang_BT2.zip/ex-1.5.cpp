#include <bits/stdc++.h>
using namespace std;

int x(int n){
	if (n==1) //dieu kien dung cua chuong trinh
	return 1;
	if (n==2) //dieu kien dung
	return 2;
	return n*(x(n-1)+(x(n-1))/(n-1)); //goi ham de quy tinh gia tri
}

int main(){
	int n; cin >> n;
	cout << x(n);
	return 0;
}