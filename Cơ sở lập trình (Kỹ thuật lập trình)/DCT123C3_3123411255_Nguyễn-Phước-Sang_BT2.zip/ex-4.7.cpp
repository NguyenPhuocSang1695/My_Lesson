//Bai 7
#include <iostream>
using namespace std;

string s;

void demkitu () {
	int dem[256]= {0}; //luu so lan xuat hien cua phan tu
	
	for (int i= 0; i< s.length(); i++){
		if (s[i]== ' '){
			continue; //neu la ki tu trong thi chuyen sang lan lap tiep theo
		}
		dem[s[i]]++; // tang so lan xuat hien cua ki tu s[i]
	}
	
	//in ra ki tu thu i va so lan xuat hien cua no
	for (int i= 0; i< 256; i++){
		if (dem[i]!= 0){
			cout << char(i) << " " << dem[i] << " ";
		}
	}
}

int main(){
	freopen("D:\\C++\\Chapter-4-exercise programing techniques\\exer-7\\input.txt", "r", stdin);
	freopen("D:\\C++\\Chapter-4-exercise programing techniques\\exer-7\\output.txt", "w", stdout);
	
	getline (cin, s);
    demkitu();
    return 0;
}
