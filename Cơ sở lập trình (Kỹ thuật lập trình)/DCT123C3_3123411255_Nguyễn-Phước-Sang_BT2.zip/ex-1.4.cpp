//Bai 4
#include <bits/stdc++.h>
using namespace std;

//Cau a
float F(int n){
	if (n==1||n==2) //dieu kien dung chuong trinh
	return 1.0;
	return F(n-2)+ F(n-1); //goi ham de quy
}

float S(int n) {
    if (n == 1) //dieu kien dung chuong trinh
    return 1.0 / (1.0 + F(1)); 
    return n / (1.0 + F(n)) + S(n-1); //goi ham de quy
}

//Cau b
float f(int n) {
    float fi=1.0; //gia tri dau tien
    float se=1.0; //gia tri thu 2
    float to; //tong
    if (n==1|| n==2)
    	return 1;
	for (int i=3; i<=n; i++){
		to= fi+se;
		fi=se;
		se=to;
	}
	return to;
}

float s(int n){
	float total= 0.0; //tong		
	for (int i=0; i<= n; i++){
		total += i / (1.0 + f(i));
	}
	return total;
}

int main(){
	cout << S(5) << endl;
	int n; cin >> n;
	cout << S(n);
	cout << "\n";
	cout << s(n);
	return 0;
}
