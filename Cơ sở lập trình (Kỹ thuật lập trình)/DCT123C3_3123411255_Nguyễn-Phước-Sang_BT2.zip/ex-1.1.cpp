//Bai 1
#include <iostream>
using namespace std;

// Cau a
long long a (long long n){
	if (n==1)
	return n;
	return n+ a(n-1);
}

// Cau b
long long b(long long n){
	if (n==1)
	return n;
	return n*n+ b(n-1);
}

//Cau c
long long c(long long n){
	if (n==1)
	return 1;
	return n*c(n-1);
}

long long sum(long long n){
	if (n==1) return 1;
	return c(n)+ sum (n-1);
}

//Cau d
long long d(long long s, long long e) {
    if (s > e) return 1;
    return s * d(s + 1, e);
}
long long sum2(long long n) {
    if (n == 1) return 2;
    return d(n, 2*n) + sum2(n - 1);
}

int main (){
	long long n; cin >> n;
	//cau a
	long long m= a(n);
	cout << m << endl;
	//cau b
	long long l= b(n);
	cout << l << endl;
	//cau c
	long long q= sum(n);
	cout << q << endl;
	//cau d
	long long p= sum2 (n);
	cout << p << endl;
	return 0;
}