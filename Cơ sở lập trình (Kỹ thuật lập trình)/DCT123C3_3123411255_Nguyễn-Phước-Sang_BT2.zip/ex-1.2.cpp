//Bai 2
#include <bits/stdc++.h>
using namespace std;

//cau a
long long a(long long n){
	if (n==1 || n==2) //dieu kien dung chuong trinh
	return 1;
	else
	return a(n-1)+(n-1)*a(n-2); //goi ham de quy tinh gia tri
}

//cau b
long long b(long long n) {
    if (n == 1 || n == 2) { //dieu kien dung chuong trinh
        return 1;
    }
    long long c = 1; //a(n-1)
    long long d = 1; //a(n-2)
    long long sum = 0; 
    for (long long i = 3; i <= n; ++i) {
        sum = c + (i - 1) * d;
        d = c; //cap nhat gia tri
        c = sum; //cap nhat gia tri
    }
    return sum;
}

int main() {
	//cau a
    cout << a(7) << endl;
    long long n; cin >> n;
    //cau b
    cout << a(n) << endl;
    //cau c
    cout << b(n);
    return 0;
}

